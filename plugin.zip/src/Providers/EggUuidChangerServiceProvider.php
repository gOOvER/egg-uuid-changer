<?php

namespace EggUuidChanger\Providers;

use Illuminate\Support\ServiceProvider;

class EggUuidChangerServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}
